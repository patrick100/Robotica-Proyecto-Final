package edmt.dev.androidcamera2api;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.graphics.drawable.ColorDrawable;
import android.hardware.Camera;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.ExifInterface;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.Formatter;
import android.util.Log;
import android.util.Size;
import android.util.SparseIntArray;
import android.view.Display;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileOutputStream;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private ImageButton btnCapture;
    private ImageButton reverseCamera;
    private TextureView textureView;


    //Check state orientation of output image


    public int orientation=0;
    private SensorManager sm;

    public Server server;

    @Override
    public void onSensorChanged(SensorEvent event) {
        // TODO Auto-generated method stub
        if (event.values[1] < 6.5 && event.values[1] > -6.5) {
            //if (orientation != 1) {
                //Log.d("Sensor", "Landscape");
                // listImage.notifyDataSetChanged();
            //}
            orientation = 1;
        } else {
            //if (orientation != 0) {
                //Log.d("Sensor", "Portrait");
                // listImage.notifyDataSetChanged();
            //}
            orientation = 0;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }




    private static final SparseIntArray ORIENTATIONS = new SparseIntArray();
    static{
        ORIENTATIONS.append(Surface.ROTATION_0,180);
        ORIENTATIONS.append(Surface.ROTATION_90,270);
        ORIENTATIONS.append(Surface.ROTATION_180,0);
        ORIENTATIONS.append(Surface.ROTATION_270,90);
    }

    private String cameraId;
    private CameraDevice cameraDevice;
    private CameraCaptureSession cameraCaptureSessions;
    private CaptureRequest.Builder captureRequestBuilder;
    private Size imageDimension;
    private ImageReader imageReader;

    //Save to FILE
    private  File file;

    //Save in samba
    SmbFile filesmb = null;
    //String sSambaFolder = "/YOROBOT/";
    String sSambaFolder = "/test/";

    String ipAddress="192.168.43.106";
    //String ipAddress="192.168.43.89";
    //String ipAddress="192.168.0.17";
    String url_salida = "";
    String url_samba="";
    NtlmPasswordAuthentication auth;
    String rpta_server="";

    //mensaje para tomar la foto
    String msg="";


    public String mypath;

    private static final int REQUEST_CAMERA_PERMISSION = 200;
    private boolean mFlashSupported;
    private Handler mBackgroundHandler;
    private HandlerThread mBackgroundThread;




    public String CAMERA_TYPE = "0";

    public Bitmap realImage;


    public CameraManager manager;
    int i=0;
    int numOfPictures = 5;


    CameraDevice.StateCallback stateCallback = new CameraDevice.StateCallback() {
        @Override
        public void onOpened(@NonNull CameraDevice camera) {
            cameraDevice = camera;
            createCameraPreview();
        }

        @Override
        public void onDisconnected(@NonNull CameraDevice cameraDevice) {
            cameraDevice.close();
        }

        @Override
        public void onError(@NonNull CameraDevice cameraDevice, int i) {
            cameraDevice.close();
            cameraDevice=null;
        }
    };


    public void reopenCamera() {
        if (textureView.isAvailable()) {
            openCamera();
        } else {
            textureView.setSurfaceTextureListener(textureListener);
        }
    }

    private void closeCamera() {
        //try {
            //mCameraOpenCloseLock.acquire();
            //closePreviewSession();

            cameraCaptureSessions.close();
            if (null != cameraDevice) {
                cameraDevice.close();
                cameraDevice = null;
            }
            //if (null != mMediaRecorder) {
            //    mMediaRecorder.release();
            //    mMediaRecorder = null;
            //}
        //} catch (InterruptedException e) {
        //    throw new RuntimeException("Interrupted while trying to lock camera closing.");
        //} //finally {
            //mCameraOpenCloseLock.release();
        //}
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textureView = (TextureView)findViewById(R.id.textureView);
        //From Java 1.4 , you can use keyword 'assert' to check expression true or false
        assert textureView != null;
        textureView.setSurfaceTextureListener(textureListener);

        sm = (SensorManager) getSystemService(SENSOR_SERVICE);

        Sensor s = sm.getSensorList(Sensor.TYPE_ACCELEROMETER).get(0);
        sm.registerListener(this,s, SensorManager.SENSOR_DELAY_NORMAL);


        auth = new NtlmPasswordAuthentication(null, null, null);

        /*
        WifiManager wifiMgr = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        WifiInfo wifiInfo = wifiMgr.getConnectionInfo();
        int ip = wifiInfo.getIpAddress();
        ipAddress = Formatter.formatIpAddress(ip);
        */

        //Toast.makeText(this, "IP: "+ipAddress , Toast.LENGTH_SHORT).show();

        url_salida = "smb://"+ ipAddress + sSambaFolder.toLowerCase();

        Toast.makeText(this, "URL "+url_salida, Toast.LENGTH_SHORT).show();


        /*SERVIDOR*/

        server = new Server(this);


        btnCapture = (ImageButton)findViewById(R.id.btnCapture);
        btnCapture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                takePicture();
            }
        });


    }




    public void takePicture() {
        if(cameraDevice == null)
            return;
        CameraManager manager = (CameraManager)getSystemService(Context.CAMERA_SERVICE);
        try{
            CameraCharacteristics characteristics = manager.getCameraCharacteristics(cameraDevice.getId());
            Size[] jpegSizes = null;
            if(characteristics != null)
                jpegSizes = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                        .getOutputSizes(ImageFormat.JPEG);

            //Capture image with custom size
            int width = 640;
            int height = 480;
            if(jpegSizes != null && jpegSizes.length > 0)
            {
                width = jpegSizes[0].getWidth();
                height = jpegSizes[0].getHeight();
            }
            final ImageReader reader = ImageReader.newInstance(width,height,ImageFormat.JPEG,1);
            List<Surface> outputSurface = new ArrayList<>(2);
            outputSurface.add(reader.getSurface());
            outputSurface.add(new Surface(textureView.getSurfaceTexture()));

            final CaptureRequest.Builder captureBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            captureBuilder.addTarget(reader.getSurface());

            //captureBuilder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO);


            //PARA ACTIVAR EL FLASH
            //captureBuilder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_TORCH);



            //Check orientation base on device
            //int rotation = getWindowManager().getDefaultDisplay().getRotation();
            //captureBuilder.set(CaptureRequest.JPEG_ORIENTATION,ORIENTATIONS.get(rotation));





            file = new File(Environment.getExternalStorageDirectory()+"/"+UUID.randomUUID().toString()+".jpg");

            //url_samba = url_salida+UUID.randomUUID().toString()+".jpg";

            //url_samba = url_salida+"img_"+String.valueOf(i)+".jpg";

            url_samba = url_salida+"imagen.jpg";


            ImageReader.OnImageAvailableListener readerListener = new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader imageReader) {
                    Image image = null;
                    try{
                        image = reader.acquireLatestImage();


                        //Toast.makeText(MainActivity.this, "MOSTRANDO DIALOGO", Toast.LENGTH_SHORT).show();



                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                                Log.v("Pe","Permission is granted");
                            }else{
                                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);

                            }
                        }

                        ByteBuffer buffer = image.getPlanes()[0].getBuffer();
                        byte[] bytes = new byte[buffer.capacity()];
                        buffer.get(bytes);


                        save(bytes);

                        //CAMBIANDO LA ROTACION DE LA IMAGEN

                        /*
                        realImage = BitmapFactory.decodeFile(file.getPath());

                        //realImage = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);



                        if(orientation==0){
                            //portrait
                            if(CAMERA_TYPE=="0"){
                                realImage= rotate(realImage, 90);
                            }

                            if(CAMERA_TYPE=="1"){
                                realImage= rotate(realImage, -90);
                            }

                        }


                        if(orientation==1){
                            //landspace
                            if(CAMERA_TYPE=="0"){
                                realImage= rotate(realImage,360);
                            }

                            if(CAMERA_TYPE=="1"){
                                realImage= rotate(realImage, -360);
                            }

                        }




                        try (FileOutputStream out = new FileOutputStream(file)) {
                            realImage.compress(Bitmap.CompressFormat.PNG, 100, out); // bmp is your Bitmap instance
                            showImage2(file);


                        } catch (IOException e) {
                            e.printStackTrace();
                        }*/



                       // try{
                       // realImage.compress(Bitmap.CompressFormat.JPEG, 50, new FileOutputStream(file));

                        //}finally {
                        //    if(ofs != null)
                        //        ofs.close();
                        //}


                        //Log.d("SOBREGUARDADO", bo + "");
                        //Toast.makeText(MainActivity.this, "SOBREGUARDADO " + bo, Toast.LENGTH_SHORT).show();

                        //ofs.close();




                        /*
                        Log.d("EXIF value", exif.getAttribute(ExifInterface.TAG_ORIENTATION));
                        if(exif.getAttribute(ExifInterface.TAG_ORIENTATION).equalsIgnoreCase("6")){
                            realImage= rotate(realImage, 90);
                        } else if(exif.getAttribute(ExifInterface.TAG_ORIENTATION).equalsIgnoreCase("8")){
                            realImage= rotate(realImage, 270);
                        } else if(exif.getAttribute(ExifInterface.TAG_ORIENTATION).equalsIgnoreCase("3")){
                            realImage= rotate(realImage, 180);
                        } else if(exif.getAttribute(ExifInterface.TAG_ORIENTATION).equalsIgnoreCase("0")){
                            realImage= rotate(realImage, 45);
                        }*/

                        //MOSTRANDO LA IMAGEN PREVIA

                    }
                    catch (FileNotFoundException e)
                    {
                        e.printStackTrace();
                    }
                    catch (IOException e)
                    {
                        e.printStackTrace();
                    }
                    finally {
                        {
                            if(image != null)
                                image.close();
                        }
                    }
                }



                private void save(byte[] bytes) throws IOException {
                    //OutputStream outputStream = null;
                    SmbFileOutputStream out=null;

                    try{
                        //outputStream = new FileOutputStream(file);
                        //outputStream.write(bytes);


                        filesmb = new SmbFile(url_samba, auth);

                        //String data = "HELLLOOOO WORLD";


                        // output is like smb://mypc/e/sharedfoldername/file.txt

                        //Toast.makeText(MainActivity.this, "SAVING IN " + filesmb.getPath().toString(), Toast.LENGTH_SHORT).show();

                        out = new SmbFileOutputStream(filesmb);
                        out.write(bytes);

                        //out.write(data.getBytes());
                        //out.flush();
                        //out.close();

                    }finally {
                        if(out != null)
                            out.close();

                        //Client myClient = new Client("192.168.0.48",12345);
                        Client myClient = new Client(ipAddress,1234);

                        myClient.execute();
                        //Toast.makeText(MainActivity.this,"RPTA SERVER: "+ myClient.response, Toast.LENGTH_SHORT).show();

                        Toast.makeText(MainActivity.this, "Guardado Correctamente", Toast.LENGTH_SHORT).show();

                    }
                }
            };

            reader.setOnImageAvailableListener(readerListener,mBackgroundHandler);
            final CameraCaptureSession.CaptureCallback captureListener = new CameraCaptureSession.CaptureCallback() {
                @Override
                public void onCaptureCompleted(@NonNull CameraCaptureSession session, @NonNull CaptureRequest request, @NonNull TotalCaptureResult result) {
                    super.onCaptureCompleted(session, request, result);
                    //Toast.makeText(MainActivity.this, "Saved "+file, Toast.LENGTH_SHORT).show();
                    createCameraPreview();
                }
            };

            cameraDevice.createCaptureSession(outputSurface, new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(@NonNull CameraCaptureSession cameraCaptureSession) {
                    try{
                        cameraCaptureSession.capture(captureBuilder.build(),captureListener,mBackgroundHandler);
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onConfigureFailed(@NonNull CameraCaptureSession cameraCaptureSession) {

                }
            },mBackgroundHandler);


        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    private void createCameraPreview() {
        try{
            SurfaceTexture texture = textureView.getSurfaceTexture();
            assert  texture != null;
            texture.setDefaultBufferSize(imageDimension.getWidth(),imageDimension.getHeight());
            Surface surface = new Surface(texture);
            captureRequestBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            captureRequestBuilder.addTarget(surface);
            cameraDevice.createCaptureSession(Arrays.asList(surface), new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(@NonNull CameraCaptureSession cameraCaptureSession) {
                    if(cameraDevice == null)
                        return;
                    cameraCaptureSessions = cameraCaptureSession;
                    updatePreview();
                }

                @Override
                public void onConfigureFailed(@NonNull CameraCaptureSession cameraCaptureSession) {
                    //Toast.makeText(MainActivity.this, "Changed-Failed Configure", Toast.LENGTH_SHORT).show();
                }
            },null);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    private void updatePreview() {
        if(cameraDevice == null)
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        captureRequestBuilder.set(CaptureRequest.CONTROL_MODE,CaptureRequest.CONTROL_MODE_AUTO);

        //captureRequestBuilder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_OFF);

        try{
            cameraCaptureSessions.setRepeatingRequest(captureRequestBuilder.build(),null,mBackgroundHandler);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }


    private void openCamera() {
        manager = (CameraManager)getSystemService(Context.CAMERA_SERVICE);
        try{
            //cameraId = manager.getCameraIdList()[0];

            cameraId = CAMERA_TYPE;
            CameraCharacteristics characteristics = manager.getCameraCharacteristics(cameraId);
            StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            assert map != null;

            //if(cameraId=="0"){
            //    imageDimension = map.getOutputSizes(SurfaceTexture.class)[0];
            //}
            //if(cameraId=="1"){
                imageDimension = map.getOutputSizes(SurfaceTexture.class)[1];
            //}


            //Check realtime permission if run higher API 23
            if(ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            {
                ActivityCompat.requestPermissions(this,new String[]{
                        Manifest.permission.CAMERA,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                },REQUEST_CAMERA_PERMISSION);
                return;
            }
            manager.openCamera(cameraId,stateCallback,null);

        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }







    TextureView.SurfaceTextureListener textureListener = new TextureView.SurfaceTextureListener() {
        @Override
        public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i1) {
            openCamera();
        }

        @Override
        public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i1) {

        }

        @Override
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
            return false;
        }

        @Override
        public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {

        }
    };

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
       if(requestCode == REQUEST_CAMERA_PERMISSION)
       {
           if(grantResults[0] != PackageManager.PERMISSION_GRANTED)
           {
               Toast.makeText(this, "You can't use camera without permission", Toast.LENGTH_SHORT).show();
                finish();
           }
       }
    }

    @Override
    protected void onResume() {
        super.onResume();
        startBackgroundThread();
        if(textureView.isAvailable())
            openCamera();
        else
            textureView.setSurfaceTextureListener(textureListener);
    }

    @Override
    protected void onPause() {
        stopBackgroundThread();
        super.onPause();
    }

    private void stopBackgroundThread() {
        mBackgroundThread.quitSafely();
        try{
            mBackgroundThread.join();
            mBackgroundThread= null;
            mBackgroundHandler = null;
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void startBackgroundThread() {
        mBackgroundThread = new HandlerThread("Camera Background");
        mBackgroundThread.start();
        mBackgroundHandler = new Handler(mBackgroundThread.getLooper());
    }
}
